// handlers/wizardHandler.js

const { Rcon } = require('rcon-client'); // <<<< اضافه شد >>>>
const callbackHandler = require('./callbackHandler.js');
const logger = require('../logger.js'); // <-- اضافه کردن لاگر

const MODULE_NAME = 'WIZARD_HANDLER';

// ثابت‌ها برای مراحل مختلف ویزاردها
const WIZARD_STEPS = {
    // Add Server Wizard
    SERVER_AWAITING_IP: 'awaiting_ip',
    SERVER_AWAITING_PORT: 'awaiting_port',
    SERVER_AWAITING_PASSWORD: 'awaiting_password',
    SERVER_AWAITING_NAME: 'awaiting_name',
    // Add Admin Wizard
    ADMIN_AWAITING_ID: 'awaiting_admin_id',
    ADMIN_AWAITING_NAME: 'awaiting_admin_name',
};

/**
 * Handles the logic for each step of any active wizard based on state stored in the database.
 */
async function handleWizardSteps(bot, msg, db, superAdminId) {
    const userId = msg.from.id;
    const chatId = msg.chat.id;
    const text = msg.text || '';

    const state = await db.getWizardState(userId);

    // If the user is not in any wizard, do nothing.
    if (!state) {
        return false;
    }
    
    logger.info(MODULE_NAME, `Processing wizard step for user ${userId}`, { wizard: state.wizard_type, step: state.step });

    // Handle cancellation command
    if (text.toLowerCase() === '/cancel') {
        logger.info(MODULE_NAME, `User ${userId} cancelled the wizard`, { wizard: state.wizard_type });
        await db.deleteWizardState(userId);
        await bot.sendMessage(chatId, 'عملیات لغو شد.');
        return true;
    }

    // Route to the correct wizard logic based on its type
    try {
        switch (state.wizard_type) {
            case 'add_server':
                await handleAddServerWizard(bot, msg, db, state, superAdminId);
                break;
            case 'add_admin':
                await handleAddAdminWizard(bot, msg, db, state);
                break;
            // Add other wizard types here in the future
            default:
                logger.warn(MODULE_NAME, `Unknown wizard type found for user ${userId}`, { state });
                await db.deleteWizardState(userId);
                return false;
        }
    } catch (error) {
        logger.error(MODULE_NAME, `An unhandled error occurred in wizard`, { userId, state, error: error.message, stack: error.stack });
        await db.deleteWizardState(userId);
        await bot.sendMessage(chatId, 'یک خطای پیش‌بینی نشده رخ داد. عملیات لغو شد.');
    }


    return true; // The message was handled by a wizard
}

/**
 * Handles steps for the "add server" wizard.
 */
async function handleAddServerWizard(bot, msg, db, state, superAdminId) {
    const userId = msg.from.id;
    const chatId = msg.chat.id;
    const text = msg.text.trim();

    // <<<<<<<<<<<<<<<<< CHANGE START >>>>>>>>>>>>>>>>>
    // مشکل شماره ۵ (بخش دوم) حل شد: اضافه کردن دکمه لغو
    // این دکمه در تمام مراحل به کاربر نمایش داده می‌شود.
    const cancelKeyboard = {
        inline_keyboard: [[{ text: '❌ لغو و بازگشت', callback_data: 'rcon_menu' }]]
    };
    // <<<<<<<<<<<<<<<<< CHANGE END >>>>>>>>>>>>>>>>>

    switch (state.step) {
        case WIZARD_STEPS.SERVER_AWAITING_IP:
            state.data.ip = text;
            logger.debug(MODULE_NAME, 'Add Server Wizard: Received IP', { userId, ip: text });
            await db.setWizardState(userId, 'add_server', WIZARD_STEPS.SERVER_AWAITING_PORT, state.data);
            await bot.sendMessage(chatId, 'عالی! حالا پورت سرور را وارد کنید:', { reply_markup: cancelKeyboard });
            break;

        case WIZARD_STEPS.SERVER_AWAITING_PORT:
            state.data.port = text;
            logger.debug(MODULE_NAME, 'Add Server Wizard: Received Port', { userId, port: text });
            await db.setWizardState(userId, 'add_server', WIZARD_STEPS.SERVER_AWAITING_PASSWORD, state.data);
            await bot.sendMessage(chatId, 'بسیار خب. حالا رمز (password) سرور RCON را وارد کنید:', { reply_markup: cancelKeyboard });
            break;

        case WIZARD_STEPS.SERVER_AWAITING_PASSWORD:
            state.data.password = text;
            logger.debug(MODULE_NAME, 'Add Server Wizard: Received Password', { userId });
            await db.setWizardState(userId, 'add_server', WIZARD_STEPS.SERVER_AWAITING_NAME, state.data);
            await bot.sendMessage(chatId, 'و در آخر، چه نامی برای این سرور ذخیره شود؟ (این نام باید یکتا باشد)', { reply_markup: cancelKeyboard });
            break;

        case WIZARD_STEPS.SERVER_AWAITING_NAME:
            state.data.name = text;
            logger.debug(MODULE_NAME, 'Add Server Wizard: Received Name', { userId, name: text });
            
            let serverId;
            try {
                // <<<<<<<<<<<<<<<<< CHANGE START >>>>>>>>>>>>>>>>>
                // مشکل شماره ۵ (بخش سوم) حل شد: تست اتصال RCON پس از ثبت
                serverId = await db.addServer(userId, state.data.name, state.data.ip, state.data.port, state.data.password);
                await db.deleteWizardState(userId); // ویزارد به پایان رسید، وضعیت پاک شود
                logger.success(MODULE_NAME, 'Add Server Wizard: Server added to DB', { userId, serverId, serverData: state.data });

                const statusMsg = await bot.sendMessage(chatId, `⏳ سرور "${state.data.name}" ذخیره شد. در حال تست اتصال...`);
                
                // تلاش برای اتصال
                const rcon = new Rcon({ host: state.data.ip, port: parseInt(state.data.port, 10), password: state.data.password });
                await rcon.connect();
                await rcon.end();
                
                // اگر اتصال موفق بود
                logger.success(MODULE_NAME, `RCON connection test successful for new server ${serverId}.`);
                await bot.editMessageText(`✅ سرور با موفقیت ذخیره و اتصال به آن تست شد!`, { chat_id: chatId, message_id: statusMsg.message_id });
                await callbackHandler.showServerMenu(bot, chatId, db, true, superAdminId);

            } catch (error) {
                await db.deleteWizardState(userId); // در صورت خطا هم ویزارد پاک شود
                
                if (error.code === 'ER_DUP_ENTRY') {
                    logger.warn(MODULE_NAME, 'Add Server Wizard: Failed due to duplicate entry', { userId, serverName: state.data.name });
                    await bot.sendMessage(chatId, `⚠️ خطا: سروری با نام "${state.data.name}" از قبل وجود دارد. لطفاً دوباره تلاش کنید.`);
                    // بازگشت به منوی سرورها
                    await callbackHandler.showServerMenu(bot, chatId, db, true, superAdminId);

                } else {
                    // اگر مشکل در اتصال RCON بود
                    logger.error(MODULE_NAME, 'RCON connection test failed after adding server', { serverId, serverData: state.data, error: error.message });
                    const failureKeyboard = {
                        inline_keyboard: [[
                            { text: '🔁 تلاش مجدد برای اتصال', callback_data: `rcon_retry_connect_${serverId}` },
                            { text: '✏️ ویرایش اطلاعات سرور', callback_data: `rcon_edit_server_${serverId}` }
                        ]]
                    };
                    await bot.sendMessage(chatId, `❌ سرور ذخیره شد، اما اتصال به RCON ناموفق بود. لطفاً اطلاعات را بررسی کنید.`, { reply_markup: failureKeyboard });
                }
            }
            // <<<<<<<<<<<<<<<<< CHANGE END >>>>>>>>>>>>>>>>>
            break;
    }
}

/**
 * Handles steps for the "add admin" wizard.
 */
async function handleAddAdminWizard(bot, msg, db, state) {
    const userId = msg.from.id;
    const chatId = msg.chat.id;

    switch (state.step) {
        case WIZARD_STEPS.ADMIN_AWAITING_ID:
            let adminId;
            if (msg.forward_from) {
                adminId = msg.forward_from.id;
            } else if (msg.text && /^\d+$/.test(msg.text.trim())) {
                adminId = parseInt(msg.text.trim(), 10);
            }

            if (adminId) {
                state.data.id = adminId;
                logger.debug(MODULE_NAME, 'Add Admin Wizard: Received ID', { initiator: userId, newAdminId: adminId });
                await db.setWizardState(userId, 'add_admin', WIZARD_STEPS.ADMIN_AWAITING_NAME, state.data);
                await bot.sendMessage(chatId, `شناسه کاربر (${adminId}) دریافت شد. حالا یک نام برای این ادمین وارد کنید:`);
            } else {
                logger.warn(MODULE_NAME, 'Add Admin Wizard: Invalid ID provided', { initiator: userId, text: msg.text });
                await bot.sendMessage(chatId, 'خطا: لطفاً یک شناسه عددی معتبر وارد کنید یا یک پیام از کاربر مورد نظر فوروارد کنید.');
            }
            break;

        case WIZARD_STEPS.ADMIN_AWAITING_NAME:
            const adminName = msg.text.trim();
            const newAdminId = state.data.id;
            logger.debug(MODULE_NAME, 'Add Admin Wizard: Received Name', { initiator: userId, newAdminId, adminName });
            try {
                await db.addAdmin(newAdminId, adminName);
                await db.deleteWizardState(userId);
                logger.success(MODULE_NAME, 'Add Admin Wizard: Admin added successfully', { initiator: userId, newAdminId, adminName });
                await bot.sendMessage(chatId, `✅ ادمین جدید با نام "${adminName}" و شناسه "${newAdminId}" با موفقیت اضافه شد.`);
                
                // A new message object is created here to avoid editing the user's message.
                const mockCallbackQuery = { message: { chat: { id: chatId }, message_id: null } }; 
                await callbackHandler.showAdminPanel(bot, db, mockCallbackQuery);

            } catch (error) {
                await db.deleteWizardState(userId);
                if (error.code === 'ER_DUP_ENTRY') {
                    logger.warn(MODULE_NAME, 'Add Admin Wizard: Failed due to duplicate entry', { initiator: userId, newAdminId });
                    await bot.sendMessage(chatId, '⚠️ این کاربر از قبل ادمین است.');
                } else {
                    logger.error(MODULE_NAME, 'Add Admin Wizard: Failed to add admin to DB', { initiator: userId, newAdminId, adminName, error: error.message, stack: error.stack });
                    await bot.sendMessage(chatId, '❌ خطایی در ذخیره ادمین رخ داد.');
                }
            }
            break;
    }
}

module.exports = { handleWizardSteps };