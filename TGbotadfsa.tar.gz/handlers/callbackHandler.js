// handlers/callbackHandler.js

const { Rcon } = require('rcon-client');
const rankManager = require('./rankManager.js');
const wizardHandler = require('./wizardHandler.js');
const logger = require('../logger.js');

const MODULE_NAME = 'CALLBACK_HANDLER';

/**
 * Escapes characters for Telegram's MarkdownV2 parse mode.
 * @param {string} text The text to escape.
 * @returns {string} The escaped text.
 */
function escapeMarkdownV2(text) {
    if (typeof text !== 'string') return '';
    return text.replace(/[_*[\]()~`>#+\-=|{}.!]/g, '\\$&');
}

/**
 * Displays the main admin management panel.
 */
async function showAdminPanel(bot, db, callbackQuery) {
    const chatId = callbackQuery.message.chat.id;
    const messageId = callbackQuery.message.message_id;
    const keyboard = {
        inline_keyboard: [
            [{ text: '➕ افزودن ادمین', callback_data: 'add_admin' }],
            [{ text: '➖ حذف ادمین', callback_data: 'remove_admin_prompt' }],
            [{ text: '👥 لیست ادمین‌ها', callback_data: 'list_admins' }],
            [{ text: '🔙 بازگشت به منوی اصلی', callback_data: 'start_menu' }]
        ]
    };
    try {
        if (messageId) {
            await bot.editMessageText('⚙️ بخش مدیریت ادمین‌ها', {
                chat_id: chatId,
                message_id: messageId,
                reply_markup: keyboard
            });
        } else {
            await bot.sendMessage(chatId, '⚙️ بخش مدیریت ادمین‌ها', { reply_markup: keyboard });
        }
    } catch (error) {
        if (!error.message.includes('message is not modified')) {
            logger.warn(MODULE_NAME, "Could not edit admin panel message, sending a new one.", { error: error.message });
            await bot.sendMessage(chatId, '⚙️ بخش مدیریت ادمین‌ها', { reply_markup: keyboard });
        }
    }
}

/**
 * Displays the RCON server management menu.
 */
async function showServerMenu(bot, context, db, isSuperAdmin, superAdminId) {
    const isCallback = typeof context === 'object' && context.message;
    const chatId = isCallback ? context.message.chat.id : context;
    const messageId = isCallback ? context.message.message_id : null;

    try {
        const userServers = await db.getServers(superAdminId);
        const serverButtons = userServers.map(server => ([{ text: `🔌 ${server.name}`, callback_data: `connect_${server.name}` }]));
        
        const keyboardRows = [...serverButtons];
        if (isSuperAdmin) {
             keyboardRows.push(
                [{ text: '➕ افزودن سرور', callback_data: 'add_server' }, { text: '➖ حذف سرور', callback_data: 'remove_server_prompt' }]
             );
        }
        keyboardRows.push([{ text: '🔙 بازگشت به منوی اصلی', callback_data: 'start_menu' }]);
        
        const keyboard = { inline_keyboard: keyboardRows };
        const messageText = userServers.length > 0
            ? 'لطفاً سرور خود را انتخاب کنید یا یک سرور جدید اضافه/حذف کنید:'
            : 'هیچ سروری ثبت نشده است. برای شروع یک سرور اضافه کنید:';

        if (isCallback && messageId) {
            await bot.editMessageText(messageText, { chat_id: chatId, message_id: messageId, reply_markup: keyboard });
        } else {
            await bot.sendMessage(chatId, messageText, { reply_markup: keyboard });
        }
    } catch (error) {
        if (!(isCallback && error.message.includes('message is not modified'))) {
            logger.error(MODULE_NAME, `An error occurred in showServerMenu for user ${chatId}`, { error: error.message, stack: error.stack });
            await bot.sendMessage(chatId, 'خطایی در نمایش منو رخ داد. لطفاً دوباره تلاش کنید.', { reply_markup: { inline_keyboard: [[{ text: '🔙 بازگشت به منوی اصلی', callback_data: 'start_menu' }]] } });
        }
    }
}

/**
 * Handles all callback queries for the bot.
 */
async function handleCallback(bot, callbackQuery, db, activeConnections, superAdminId, mainBotUsername, setupRankListCron) {
    const action = callbackQuery.data;
    const msg = callbackQuery.message;
    const chatId = msg.chat.id;
    const userId = callbackQuery.from.id;
    const messageId = msg.message_id;

    logger.info(MODULE_NAME, `Callback received`, { userId, chatId, action });

    const isSuperAdmin = (userId === superAdminId);

    try {
        // --- Route to specialized handlers first ---
        if (action.startsWith('rankmgr_') || action.startsWith('rank_interval_')) {
            await bot.answerCallbackQuery(callbackQuery.id);
            logger.debug(MODULE_NAME, `Routing to RankManager`, { action });
            return rankManager.handleRankManagerCallback(bot, callbackQuery, db, setupRankListCron);
        }
        if (action.startsWith('register_')) {
            logger.debug(MODULE_NAME, `Routing to RegistrationHandler`, { action });
            return require('./registrationHandler.js').handleRegistrationCallback(bot, callbackQuery, db);
        }

        await bot.answerCallbackQuery(callbackQuery.id);

        // --- Main Callback Logic ---
        switch (true) {
            // ===================================
            // Main Menus
            // ===================================
            case action === 'start_menu': {
                logger.debug(MODULE_NAME, 'Executing action: start_menu');
                const baseKeyboard = [[{ text: 'اتصال مستقیم به rcon', callback_data: 'rcon_menu' }]];
                if (isSuperAdmin) {
                    baseKeyboard.push([{ text: '⚙️ بخش مدیریت ادمین‌ها', callback_data: 'admin_panel' }]);
                    baseKeyboard.push([{ text: '🏆 مدیریت لیست رنک', callback_data: 'manage_rank_list' }]);
                }
                await bot.editMessageText('سلام! 👋 برای شروع یکی از گزینه‌ها را انتخاب کن.', {
                    chat_id: chatId, message_id: messageId, reply_markup: { inline_keyboard: baseKeyboard }
                });
                break;
            }
            case action === 'rcon_menu':
                logger.debug(MODULE_NAME, 'Executing action: rcon_menu');
                await showServerMenu(bot, callbackQuery, db, isSuperAdmin, superAdminId);
                break;

            case action === 'manage_rank_list':
                logger.debug(MODULE_NAME, 'Executing action: manage_rank_list');
                if (!isSuperAdmin) return;
                await bot.deleteMessage(chatId, messageId);
                await rankManager.startRankManager(bot, msg, db, setupRankListCron);
                break;

            // ===================================
            // User Account Panel
            // ===================================
            case action === 'manage_account': {
                 logger.debug(MODULE_NAME, 'Executing action: manage_account');
                 const message = '🔧 *پنل مدیریت اکانت*\n\nاز گزینه‌های زیر برای مدیریت حساب کاربری خود استفاده کنید:';
                 const keyboard = { inline_keyboard: [
                     [{ text: '💎 کسب درآمد و زیرمجموعه‌گیری', callback_data: 'show_referral_info' }],
                     [{ text: '🔙 بازگشت', callback_data: 'user_start_menu' }]
                 ]};
                 await bot.editMessageText(message, { chat_id: chatId, message_id: messageId, reply_markup: keyboard, parse_mode: 'Markdown' });
                 break;
            }
            case action === 'show_referral_info': {
                logger.debug(MODULE_NAME, 'Executing action: show_referral_info');
                const referralLink = `https://t.me/${mainBotUsername}?start=${userId}`;
                const message = `💎 *با دعوت از دوستات، هم بازی کن هم درآمد داشته باش!*\n\nاین لینک جادویی توئه! هر کسی باهاش بیاد تو سرور، تو رو برای همیشه پولدار می‌کنه! 😉\n\n*لینک دعوت تو:*\n\`${referralLink}\`\n(روی لینک بالا کلیک کن تا کپی بشه)\n\n*چطوری؟ اینجوری:*\n- هر خریدی که دوستات بکنن، *۲۵ درصدش* مستقیم میره تو جیب تو!\n- حتی اگه دوستات هم کسی رو دعوت کنن، *۵ درصد* از خرید اونها هم برای توئه!\n\nهمین الان لینک رو برای دوستات بفرست و تیم خودت رو بساز!`;
                const keyboard = { inline_keyboard: [[{ text: '🔙 بازگشت به پنل اکانت', callback_data: 'manage_account' }]] };
                await bot.editMessageText(message, { chat_id: chatId, message_id: messageId, reply_markup: keyboard, parse_mode: 'Markdown' });
                break;
            }
            case action === 'user_start_menu': {
                logger.debug(MODULE_NAME, 'Executing action: user_start_menu');
                const message = '🎉 به پنل کاربری خود خوش آمدید!\n\nاز طریق دکمه زیر می‌توانید اکانت خود را مدیریت کرده و لینک زیرمجموعه‌گیری خود را دریافت کنید.';
                const keyboard = { inline_keyboard: [[{ text: '🔧 مدیریت اکانت', callback_data: 'manage_account' }]] };
                await bot.editMessageText(message, { chat_id: chatId, message_id: messageId, reply_markup: keyboard });
                break;
            }

            // ===================================
            // Admin Management
            // ===================================
            case action === 'admin_panel':
                logger.debug(MODULE_NAME, 'Executing action: admin_panel');
                if (isSuperAdmin) await showAdminPanel(bot, db, callbackQuery);
                break;
            case action === 'add_admin':
                logger.debug(MODULE_NAME, 'Executing action: add_admin');
                if (!isSuperAdmin) return;
                await db.setWizardState(userId, 'add_admin', 'awaiting_admin_id', {});
                await bot.editMessageText('لطفاً شناسه عددی (User ID) کاربر مورد نظر را ارسال کنید، یا یک پیام از او فوروارد کنید:', { chat_id: chatId, message_id: messageId });
                break;
            case action === 'list_admins': {
                logger.debug(MODULE_NAME, 'Executing action: list_admins');
                if (!isSuperAdmin) return;
                const admins = await db.getAdmins();
                let adminList = '👥 *لیست ادمین‌ها:*\n\n';
                if (admins.length === 0) {
                    adminList = 'هیچ ادمینی ثبت نشده است.';
                } else {
                    admins.forEach(admin => {
                        adminList += `👤 *نام:* ${escapeMarkdownV2(admin.name)}\n🆔 *شناسه:* \`${admin.user_id}\`\n\n`;
                    });
                }
                await bot.editMessageText(adminList, { chat_id: chatId, message_id: messageId, parse_mode: 'MarkdownV2', reply_markup: { inline_keyboard: [[{ text: '🔙 بازگشت', callback_data: 'admin_panel' }]] } });
                break;
            }
            case action.startsWith('remove_admin'): {
                // Combined remove admin logic for brevity
                const parts = action.split('_');
                const stage = parts[2];
                const adminIdToRemove = parts[3];

                if (!isSuperAdmin) return;

                if (stage === 'prompt') {
                    const admins = await db.getAdmins();
                    if (admins.length === 0) return bot.answerCallbackQuery(callbackQuery.id, { text: 'هیچ ادمینی برای حذف وجود ندارد.', show_alert: true });
                    const adminButtons = admins.map(admin => ([{ text: `🗑️ ${admin.name}`, callback_data: `remove_admin_confirm_${admin.user_id}` }]));
                    adminButtons.push([{ text: '🔙 بازگشت', callback_data: 'admin_panel' }]);
                    await bot.editMessageText('کدام ادمین را می‌خواهید حذف کنید؟', { chat_id: chatId, message_id: messageId, reply_markup: { inline_keyboard: adminButtons } });
                } else if (stage === 'confirm') {
                    const keyboard = { inline_keyboard: [[{ text: '🚫 نه، بی‌خیال', callback_data: 'admin_panel' }, { text: '✅ بله، حذف کن', callback_data: `remove_admin_execute_${adminIdToRemove}` }]] };
                    await bot.editMessageText(`آیا از حذف ادمین با شناسه \`${adminIdToRemove}\` مطمئن هستید؟`, { chat_id: chatId, message_id: messageId, reply_markup: keyboard, parse_mode: 'Markdown' });
                } else if (stage === 'execute') {
                    await db.removeAdmin(parseInt(adminIdToRemove, 10));
                    logger.success(MODULE_NAME, `Admin ${adminIdToRemove} removed successfully.`);
                    await showAdminPanel(bot, db, callbackQuery);
                }
                break;
            }

            // ===================================
            // Server Management
            // ===================================
            case action === 'add_server':
                logger.debug(MODULE_NAME, 'Executing action: add_server');
                if (!isSuperAdmin) return;
                await db.setWizardState(userId, 'add_server', 'awaiting_ip', {});
                await bot.editMessageText('لطفاً آدرس IP یا دامنه سرور را وارد کنید:', { chat_id: chatId, message_id: messageId });
                break;
            case action.startsWith('remove_server'): {
                // Combined remove server logic
                const parts = action.split('_');
                const stage = parts[2];
                const serverName = parts.slice(3).join('_');

                if (!isSuperAdmin) return;

                if (stage === 'prompt') {
                    const servers = await db.getServers(superAdminId);
                    if (servers.length === 0) return bot.answerCallbackQuery(callbackQuery.id, { text: 'هیچ سروری برای حذف وجود ندارد.', show_alert: true });
                    const serverButtons = servers.map(server => ([{ text: `🗑️ ${server.name}`, callback_data: `remove_server_confirm_${server.name}` }]));
                    serverButtons.push([{ text: '🔙 بازگشت', callback_data: 'rcon_menu' }]);
                    await bot.editMessageText('کدام سرور را می‌خواهید حذف کنید؟', { chat_id: chatId, message_id: messageId, reply_markup: { inline_keyboard: serverButtons } });
                } else if (stage === 'confirm') {
                    const keyboard = { inline_keyboard: [[{ text: '🚫 نه، بی‌خیال', callback_data: 'rcon_menu' }, { text: '✅ بله، حذف کن', callback_data: `remove_server_execute_${serverName}` }]] };
                    await bot.editMessageText(`آیا از حذف سرور "${serverName}" مطمئن هستید؟`, { chat_id: chatId, message_id: messageId, reply_markup: keyboard });
                } else if (stage === 'execute') {
                    await db.deleteServer(userId, serverName);
                    logger.success(MODULE_NAME, `Server '${serverName}' removed successfully.`);
                    await showServerMenu(bot, callbackQuery, db, isSuperAdmin, superAdminId);
                }
                break;
            }
            
            // ===================================
            // RCON Connection
            // ===================================
            case action.startsWith('connect_'): {
                const serverName = action.substring('connect_'.length);
                logger.debug(MODULE_NAME, `Attempting RCON connection to server`, { serverName });
                const escapedServerName = escapeMarkdownV2(serverName);
                let sentMessage = await bot.editMessageText(`⏳ در حال تلاش برای اتصال به سرور *${escapedServerName}* \\.\\.\\.`, { chat_id: chatId, message_id: messageId, parse_mode: 'MarkdownV2' });
                
                try {
                    const userServers = await db.getServers(superAdminId);
                    const server = userServers.find(s => s.name === serverName);
                    if (!server) throw new Error(`Server '${serverName}' not found in database.`);
                    
                    const rcon = new Rcon({ host: server.ip, port: parseInt(server.port, 10), password: server.password });
                    await rcon.connect();
                    
                    rcon.initiatedDisconnect = false; 
                    activeConnections[userId] = rcon;
                    
                    rcon.on('error', (err) => logger.error(MODULE_NAME, `RCON error for user ${userId}`, { error: err.message }));
                    rcon.on('end', () => {
                        if (activeConnections[userId] && !rcon.initiatedDisconnect) {
                            delete activeConnections[userId];
                            logger.info(MODULE_NAME, `RCON connection was closed by the server for user ${userId}.`);
                            bot.sendMessage(userId, 'ℹ️ اتصال شما از طرف سرور بسته شد.');
                        }
                    });
                    
                    logger.success(MODULE_NAME, `RCON connection successful for user ${userId} to server '${serverName}'.`);
                    const successMessage = `✅ اتصال به سرور *${escapedServerName}* موفقیت‌آمیز بود\\.\n\nحالا می‌تونی دستوراتت رو بفرستی\\.\nبرای خروج از دستور /disconnect استفاده کن\\.`;
                    await bot.editMessageText(successMessage, { chat_id: chatId, message_id: sentMessage.message_id, parse_mode: 'MarkdownV2' });

                } catch (error) {
                    logger.error(MODULE_NAME, `RCON connection failed for server '${serverName}'`, { error: error.message, stack: error.stack });
                    const errorMessage = `❌ اتصال به سرور *${escapedServerName}* ناموفق بود\\.\n\nرمز اشتباه است یا سرور در دسترس نیست\\.`;
                    await bot.editMessageText(errorMessage, { chat_id: chatId, message_id: sentMessage.message_id, parse_mode: 'MarkdownV2' });
                }
                break;
            }

            // <<<<<<<<<<<<<<<<< CHANGE START >>>>>>>>>>>>>>>>>
            // مشکل شماره ۵ (بخش چهارم) حل شد: مدیریت دکمه‌های جدید
            case action.startsWith('rcon_retry_connect_'): {
                if (!isSuperAdmin) return;
                const serverId = parseInt(action.split('_').pop(), 10);
                const allServers = await db.getServers(superAdminId);
                const server = allServers.find(s => s.id === serverId);

                if (!server) {
                    await bot.answerCallbackQuery(callbackQuery.id, { text: 'سرور یافت نشد یا حذف شده است!', show_alert: true });
                    return bot.deleteMessage(chatId, messageId);
                }

                await bot.editMessageText(`⏳ در حال تلاش مجدد برای اتصال به سرور "${server.name}"...`, { chat_id: chatId, message_id: messageId, reply_markup: null });
                try {
                    const rcon = new Rcon({ host: server.ip, port: parseInt(server.port, 10), password: server.password });
                    await rcon.connect();
                    await rcon.end();
                    await bot.editMessageText('✅ اتصال موفقیت‌آمیز بود!', { chat_id: chatId, message_id: messageId });
                    await showServerMenu(bot, callbackQuery, db, isSuperAdmin, superAdminId);
                } catch (error) {
                    logger.error(MODULE_NAME, `RCON retry connect failed for server ${serverId}`, { error: error.message });
                    await bot.answerCallbackQuery(callbackQuery.id, { text: 'اتصال باز هم ناموفق بود.', show_alert: true });
                    await bot.editMessageText(`❌ اتصال به RCON ناموفق بود. لطفاً اطلاعات را بررسی کنید.`, { 
                        chat_id: chatId, 
                        message_id: messageId, 
                        reply_markup: msg.reply_markup
                    });
                }
                break;
            }

            case action.startsWith('rcon_edit_server_'): {
                if (!isSuperAdmin) return;
                const serverId = parseInt(action.split('_').pop(), 10);
                const allServers = await db.getServers(superAdminId);
                const server = allServers.find(s => s.id === serverId);

                if (server) {
                    await db.deleteServer(userId, server.name);
                }
                
                await bot.editMessageText('اطلاعات سرور قبلی حذف شد. لطفاً فرآیند ثبت را از ابتدا شروع کنید.', { chat_id: chatId, message_id: messageId, reply_markup: null });
                await db.setWizardState(userId, 'add_server', 'awaiting_ip', {});
                await bot.sendMessage(chatId, 'لطفاً آدرس IP یا دامنه سرور جدید را وارد کنید:');
                break;
            }
            // <<<<<<<<<<<<<<<<< CHANGE END >>>>>>>>>>>>>>>>>
            
            default:
                logger.warn(MODULE_NAME, `Unknown callback action received`, { action, userId });
        }
    } catch (e) {
        if (!e.message.includes('message is not modified')) {
             logger.error(MODULE_NAME, `A critical error occurred for action "${action}"`, { error: e.message, stack: e.stack });
        }
    }
}

module.exports = { handleCallback, showServerMenu, showAdminPanel };