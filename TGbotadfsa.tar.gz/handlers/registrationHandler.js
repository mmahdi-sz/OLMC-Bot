// handlers/registrationHandler.js

const crypto = require('crypto');
const logger = require('../logger.js'); // <-- اضافه کردن لاگر

const MODULE_NAME = 'REGISTRATION_HANDLER';

// مراحل مختلف ویزارد ثبت‌نام
const WIZARD_STEPS = {
    AWAITING_EDITION: 'awaiting_edition',
    AWAITING_USERNAME: 'awaiting_username',
    AWAITING_AGE: 'awaiting_age',
};

// الگوی Regex برای اعتبارسنجی نام کاربری ماینکرفت (Java Edition)
const MINECRAFT_USERNAME_REGEX = /^[a-zA-Z0-9_]{3,16}$/;

/**
 * نقطه شروع برای فرآیند ثبت‌نام کاربر.
 */
async function startRegistration(bot, msg, referrerId = null, db) {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    logger.info(MODULE_NAME, `Starting registration process for user ${userId}`, { referrerId: referrerId || 'none' });

    const wizardData = { referrerId: referrerId || null };
    await db.setWizardState(userId, 'registration', WIZARD_STEPS.AWAITING_EDITION, wizardData);

    const message = "👋 سلام، به بات ادرلend خوش آمدید.\nبرای شروع فرآیند ثبت‌نام در سرور، روی دکمه زیر کلیک کنید.";
    const keyboard = {
        inline_keyboard: [
            [{ text: '📝 ثبت نام در سرور', callback_data: 'register_start' }]
        ]
    };
    await bot.sendMessage(chatId, message, { reply_markup: keyboard });
}

/**
 * مدیریت کلیک روی دکمه‌های شیشه‌ای در فرآیند ثبت‌نام.
 */
async function handleRegistrationCallback(bot, callbackQuery, db) {
    const action = callbackQuery.data;
    const msg = callbackQuery.message;
    const chatId = msg.chat.id;
    const userId = callbackQuery.from.id;

    try {
        await bot.answerCallbackQuery(callbackQuery.id); // پاسخ به تلگرام برای جلوگیری از لودینگ دکمه
        const userState = await db.getWizardState(userId);

        switch (action) {
            case 'register_start':
                logger.debug(MODULE_NAME, `User ${userId} clicked 'register_start'`);
                if (!userState || userState.wizard_type !== 'registration') {
                    logger.warn(MODULE_NAME, `User ${userId} had no state, creating a new one.`);
                    await db.setWizardState(userId, 'registration', WIZARD_STEPS.AWAITING_EDITION, userState?.data || {});
                }
                
                await bot.editMessageText('لطفا نسخه بازی خود را انتخاب کنید:', {
                    chat_id: chatId,
                    message_id: msg.message_id,
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '☕️ جاوا ادیشن', callback_data: 'register_edition_java' }],
                            [{ text: '📱 بدراک ادیشن', callback_data: 'register_edition_bedrock' }]
                        ]
                    }
                });
                break;

            case 'register_edition_java':
            case 'register_edition_bedrock':
                if (!userState || userState.step !== WIZARD_STEPS.AWAITING_EDITION) return;
                
                const edition = (action === 'register_edition_java') ? 'java' : 'bedrock';
                userState.data.edition = edition;
                logger.debug(MODULE_NAME, `User ${userId} selected edition`, { edition });
                await db.setWizardState(userId, 'registration', WIZARD_STEPS.AWAITING_USERNAME, userState.data);

                await bot.editMessageText('✅ نسخه بازی شما ثبت شد.\n\nلطفاً نام کاربری دقیق خود را در بازی وارد کنید:', {
                    chat_id: chatId,
                    message_id: msg.message_id
                });
                break;
        }
    } catch (error) {
        if (!error.message.includes('message is not modified')) {
            logger.error(MODULE_NAME, `Error in registration callback for user ${userId}`, { action, error: error.message, stack: error.stack });
        }
    }
}

/**
 * مدیریت پیام‌های متنی کاربر در طول ویزارد ثبت‌نام.
 */
async function handleRegistrationWizard(bot, msg, db) {
    const userId = msg.from.id;
    const chatId = msg.chat.id;
    const text = msg.text || '';

    const state = await db.getWizardState(userId);
    if (!state || state.wizard_type !== 'registration') {
        return false;
    }

    switch (state.step) {
        case WIZARD_STEPS.AWAITING_USERNAME:
            const username = text.trim();
            if (!MINECRAFT_USERNAME_REGEX.test(username)) {
                logger.warn(MODULE_NAME, `User ${userId} provided invalid username`, { username });
                await bot.sendMessage(chatId, '⚠️ نام کاربری نامعتبر است.\nنام کاربری باید بین ۳ تا ۱۶ کاراکتر باشد و فقط شامل حروف انگلیسی، اعداد و خط زیر (_) باشد. لطفاً دوباره تلاش کنید.');
                return true;
            }

            // <<<<<<<<<<<<<<<<< CHANGE START >>>>>>>>>>>>>>>>>
            // بررسی تکراری بودن نام کاربری
            // نکته: تابع isUsernameTaken باید به فایل database.js اضافه شود.
            const isTaken = await db.isUsernameTaken(username);
            if (isTaken) {
                logger.warn(MODULE_NAME, `User ${userId} tried to register with a taken username`, { username });
                const supportAdminUsername = process.env.SUPPORT_ADMIN_USERNAME || 'otherland_admin';
                await bot.sendMessage(chatId, `شما مجاز به استفاده از این نام کاربری نیستید زیرا توسط فرد دیگری گرفته شده است.\nبه راهنمایی نیاز دارید؟؟؟ به @${supportAdminUsername} پیام بدید`);
                return true; // کاربر در همین مرحله باقی می‌ماند تا نام دیگری وارد کند
            }
            // <<<<<<<<<<<<<<<<< CHANGE END >>>>>>>>>>>>>>>>>

            state.data.username = username;
            logger.debug(MODULE_NAME, `User ${userId} provided username`, { username });
            await db.setWizardState(userId, 'registration', WIZARD_STEPS.AWAITING_AGE, state.data);
            
            // <<<<<<<<<<<<<<<<< CHANGE START >>>>>>>>>>>>>>>>>
            // بهبود پیام درخواست سن با افزودن مثال
            await bot.sendMessage(chatId, `✅ نام کاربری "${username}" ثبت شد.\n\nلطفا سن خود را وارد کنید\nمانند: \`15\``, { parse_mode: 'Markdown' });
            // <<<<<<<<<<<<<<<<< CHANGE END >>>>>>>>>>>>>>>>>
            break;

        case WIZARD_STEPS.AWAITING_AGE:
            const ageText = text.trim().replace(/[\u0660-\u0669]/g, c => c.charCodeAt(0) - 0x0660);
            const age = parseInt(ageText, 10);

            if (isNaN(age) || age < 10 || age > 70) {
                logger.warn(MODULE_NAME, `User ${userId} provided invalid age`, { ageText });
                await bot.sendMessage(chatId, '⚠️ سن وارد شده معتبر نیست. لطفاً یک عدد بین ۱۰ تا ۷۰ وارد کنید.');
                return true;
            }

            state.data.age = age;
            logger.debug(MODULE_NAME, `User ${userId} provided age`, { age });
            
            try {
                const uuid = crypto.randomBytes(8).toString('hex').toUpperCase();
                let finalUsername = state.data.username;

                if (state.data.edition === 'bedrock') {
                    finalUsername = finalUsername.replace(/\s/g, '_');
                    if (!finalUsername.startsWith('_')) {
                         finalUsername = `_${finalUsername}`;
                    }
                }
                
                const registrationData = {
                    telegram_user_id: userId,
                    game_edition: state.data.edition,
                    game_username: finalUsername,
                    age: state.data.age,
                    uuid: uuid,
                    referrer_telegram_id: state.data.referrerId || null
                };

                await db.addRegistration(registrationData);
                logger.success(MODULE_NAME, `User ${userId} successfully registered`, { data: registrationData });

                const supportAdminUsername = process.env.SUPPORT_ADMIN_USERNAME || 'otherland_admin';
                const escapedUsername = supportAdminUsername.replace(/_/g, '\\_');
                const finalMessage = `✅ ثبت‌نام اولیه شما با موفقیت انجام شد!\n\nاین کد ثبت‌نام شماست. لطفاً آن را کپی کرده و برای ادمین پشتیبانی (@${escapedUsername}) ارسال کنید تا ثبت‌نام شما نهایی شود.`;
                
                await bot.sendMessage(chatId, finalMessage, { parse_mode: 'Markdown' });
                await bot.sendMessage(chatId, `\`${uuid}\``, { parse_mode: 'Markdown' });

            } catch (error) {
                logger.error(MODULE_NAME, `Error finalizing registration for user ${userId}`, { error: error.message, stack: error.stack });
                await bot.sendMessage(chatId, '❌ متاسفانه در مرحله آخر ثبت‌نام خطایی رخ داد. لطفاً بعداً دوباره تلاش کنید.');
            } finally {
                await db.deleteWizardState(userId);
                logger.debug(MODULE_NAME, `Wizard state for user ${userId} has been cleared.`);
            }
            break;
    }
    return true;
}

/**
 * مدیریت دستور حذف یک درخواست ثبت‌نام توسط سوپر ادمین.
 */
async function handleDeleteRegistration(bot, msg, db, superAdminId) {
    const requesterId = msg.from.id;
    if (requesterId !== superAdminId) return;

    const parts = msg.text.split(' ');
    if (parts.length < 2) {
        return bot.sendMessage(requesterId, 'استفاده صحیح: `/del <UUID>`');
    }
    const uuid = parts[1].trim();
    logger.info(MODULE_NAME, `SuperAdmin ${requesterId} is attempting to delete registration`, { uuid });

    try {
        const result = await db.deleteRegistration(uuid);
        if (result.affectedRows > 0) {
            logger.success(MODULE_NAME, `Registration with UUID ${uuid} deleted successfully.`);
            await bot.sendMessage(requesterId, `✅ درخواست ثبت‌نام با UUID \`${uuid}\` با موفقیت حذف شد.`, { parse_mode: 'Markdown' });
        } else {
            logger.warn(MODULE_NAME, `Registration with UUID ${uuid} not found for deletion.`);
            await bot.sendMessage(requesterId, `⚠️ درخواستی با UUID \`${uuid}\` پیدا نشد.`, { parse_mode: 'Markdown' });
        }
    } catch (error) {
        logger.error(MODULE_NAME, `Error deleting registration with UUID ${uuid}`, { error: error.message, stack: error.stack });
        await bot.sendMessage(requesterId, '❌ خطایی در هنگام حذف از دیتابیس رخ داد.');
    }
}

module.exports = {
    startRegistration,
    handleRegistrationCallback,
    handleRegistrationWizard,
    handleDeleteRegistration
};